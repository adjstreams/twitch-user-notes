# Twitch User Notes
A Chrome extension to save personal notes about Twitch users.