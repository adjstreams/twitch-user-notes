import { openOptionsAndClose } from "./logic";

const btn = document.getElementById("open");
btn?.addEventListener("click", openOptionsAndClose);
